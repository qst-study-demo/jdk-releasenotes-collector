# JDK Issue Analyzer

JDKバージョン間のIssue(バグ修正、機能追加、変更など)を分析し、アプリケーションへの影響を評価するスキルです。

## 主な機能

- 📊 **複数バージョンの同時分析**: 複数のJDKバージョンを統合して分析
- 🔍 **高度な検索機能**: キーワード、優先度、コンポーネント、OSでフィルタリング
- 📈 **統計情報の可視化**: Chart.jsを使ったインタラクティブなグラフ
- 📝 **HTMLレポート生成**: テンプレート方式または部品組み立て方式
- 🎯 **Windows 11専用分析**: Windows 11環境への影響に特化したレポート

## クイックスタート

### 標準レポートの生成

```bash
cd scripts
python3 generate_report.py 21.0.6 21.0.7 21.0.8
```

### Windows 11専用レポートの生成

```bash
cd scripts
python3 generate_windows11_report.py 21.0.6
```

### カスタムレポートの作成

```python
from html_components import generate_summary_cards_section, wrap_in_html_template
from jdk_issue_statistics import load_multiple_files

stats = load_multiple_files(['../references/jdk_OpenJDK21_0_6_Released.txt'])

cards = generate_summary_cards_section([
    {'label': '総Issue数', 'value': len(stats.issues), 'style': 'total'},
])

html = wrap_in_html_template(cards, title='My Report')
with open('report.html', 'w') as f:
    f.write(html)
```

## ドキュメント

- **[QUICKSTART.md](QUICKSTART.md)** - 5分でわかるクイックスタートガイド
- **[SKILL.md](SKILL.md)** - 包括的な機能説明と使用方法
- **[COMPONENTS.md](COMPONENTS.md)** - HTML部品システムの詳細ガイド
- **[MULTI_TEMPLATE.md](MULTI_TEMPLATE.md)** - マルチテンプレートシステムの詳細

## プロジェクト構成

```
jdk-issue-analyzer/
├── scripts/                      # 実行スクリプト
│   ├── generate_report.py        # 標準レポート生成
│   ├── generate_windows11_report.py  # Windows 11専用レポート
│   ├── html_generator.py         # テンプレートジェネレーター
│   ├── html_components.py        # HTML部品モジュール
│   ├── search_issues.py          # Issue検索
│   └── example_manual_report.py  # カスタムレポート作成例
│
├── templates/                    # HTMLテンプレート
│   ├── report_template.html
│   └── windows11_specialized_template.html
│
├── references/                   # データファイル
│   ├── jdk_OpenJDK21_0_6_Released.txt
│   ├── jdk_OpenJDK21_0_7_Released.txt
│   └── jdk_OpenJDK21_0_8_Released.txt
│
└── docs/                         # ドキュメント
    ├── README.md                 # このファイル
    ├── QUICKSTART.md
    ├── SKILL.md
    ├── COMPONENTS.md
    └── MULTI_TEMPLATE.md
```

## レポート作成の2つのアプローチ

### 1. テンプレート方式（自動化）

標準的なレポート形式が決まっている場合に最適。

**メリット:**
- 完全自動化
- 高速生成（0.003秒/レポート）
- 一貫した品質

**使用例:**
```bash
# 標準レポート
python3 generate_report.py 21.0.6

# Windows 11専用レポート
python3 generate_windows11_report.py 21.0.6
```

### 2. 部品組み立て方式（柔軟性）

カスタムレイアウトが必要な場合に最適。

**メリット:**
- 完全な柔軟性
- 必要な部品だけを選択
- HTMLの手書き不要

**使用例:**
```python
from html_components import (
    generate_summary_card,
    generate_key_findings,
    generate_issue_table,
    wrap_in_html_template
)

# 必要な部品を組み合わせ
card = generate_summary_card('総Issue数', 77)
findings = generate_key_findings('発見事項', ['P2が5件'])
table = generate_issue_table([...])

html = wrap_in_html_template(f'{card}{findings}{table}')
```

## 利用可能なJDKバージョン

- OpenJDK 21.0.6
- OpenJDK 21.0.7
- OpenJDK 21.0.8

## 主なユースケース

### Windows 11環境への影響調査

```bash
# Windows関連Issueの検索
python3 search_issues.py --os windows --verbose

# Windows 11専用レポート生成
python3 generate_windows11_report.py 21.0.6

# 高優先度Windows関連Issue
python3 search_issues.py --os windows --priority P2
```

### セキュリティ関連の変更確認

```bash
# security-libsコンポーネントの変更
python3 search_issues.py --component security-libs

# セキュリティキーワードで検索
python3 search_issues.py --search "security" --verbose
```

### パフォーマンス改善の確認

```bash
# hotspotコンポーネントの変更（JVM関連）
python3 search_issues.py --component hotspot

# パフォーマンスキーワードで検索
python3 search_issues.py --search "performance" --verbose
```

### バージョン横断的な分析

```bash
# 全バージョンでP2のIssueを検索
python3 search_issues.py --priority P2 --merge --file \
  ../references/jdk_OpenJDK21_0_6_Released.txt \
  ../references/jdk_OpenJDK21_0_7_Released.txt \
  ../references/jdk_OpenJDK21_0_8_Released.txt
```

## パフォーマンス

- **データ読み込み**: 0.002秒（373 Issues）
- **HTML生成**: 0.003秒（平均）
- **処理速度**: 130,091 Issues/秒
- **メモリ効率**: 軽量で大量のIssueも処理可能

## 要件

- Python 3.8以上
- Jinja2（推奨、フォールバック機能あり）

```bash
pip install jinja2
```

## テスト

```bash
cd scripts

# HTML生成のテスト
python3 test_html_generator.py

# マルチテンプレートのテスト
python3 test_multi_template.py

# カスタムレポート作成例
python3 example_manual_report.py
```

## トラブルシューティング

### データファイルが見つからない

```bash
# scriptsディレクトリに移動
cd scripts
```

### HTMLレポートが表示されない

ローカルサーバーを起動:
```bash
python3 -m http.server 8000
```

ブラウザで `http://localhost:8000/report.html` にアクセス

## ライセンス

このプロジェクトは、JDK Issue Analyzerスキルの一部として提供されています。

## 貢献

改善提案やバグ報告は、以下の方法で受け付けています:
- Issueの作成
- Pull Requestの提出

## 関連リソース

- [OpenJDK Bug System](https://bugs.openjdk.org/)
- [JDK Release Notes](https://www.oracle.com/java/technologies/javase/jdk-relnotes-index.html)
- [Chart.js Documentation](https://www.chartjs.org/)
- [Jinja2 Documentation](https://jinja.palletsprojects.com/)

## FAQ

**Q: テンプレートと部品、どちらを使うべきですか？**

A: 標準的なレポートにはテンプレートを、カスタムレイアウトが必要な場合は部品を使用してください。詳細は [QUICKSTART.md](QUICKSTART.md) を参照。

**Q: 新しいJDKバージョンのデータを追加できますか？**

A: はい、`references/` ディレクトリに同じフォーマットのテキストファイルを追加すれば自動的に利用可能になります。

**Q: 複数バージョンを同時に分析できますか？**

A: はい、`--file` オプションで複数ファイルを指定するか、`--merge` オプションで統合分析が可能です。

**Q: カスタムテンプレートを追加できますか？**

A: はい、[MULTI_TEMPLATE.md](MULTI_TEMPLATE.md) の「カスタムテンプレートの作成」を参照してください。

## 更新履歴

- **v2.0** - マルチテンプレートシステムと部品化システムを追加
- **v1.5** - Windows 11専用レポート機能を追加
- **v1.0** - 初期リリース（標準レポート生成、Issue検索）

## サポート

質問や問題がある場合は、[SKILL.md](SKILL.md) の詳細ドキュメントを参照するか、Issueを作成してください。
