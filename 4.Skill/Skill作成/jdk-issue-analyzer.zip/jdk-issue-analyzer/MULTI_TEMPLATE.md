# マルチテンプレートシステム

HTMLジェネレーターは複数のテンプレートをサポートしており、目的に応じて適切なテンプレートを選択できます。

## 利用可能なテンプレート

### 1. 標準テンプレート (`standard`)

**ファイル:** `templates/report_template.html`

**用途:** 全Issue対象の包括的な分析レポート

**特徴:**
- 総Issue数、高優先度Issue数、Windows関連Issue数、セキュリティ関連Issue数のサマリーカード
- 優先度別、コンポーネント別、タイプ別、OS別の分布グラフ（Chart.js）
- インタラクティブなIssue一覧テーブル（ソート・フィルタリング機能付き）
- フル機能の検索・フィルタ機能

**使用例:**
```python
from html_generator import HTMLGenerator, prepare_report_data

generator = HTMLGenerator(template_name='standard')
data = prepare_report_data(stats, versions)
generator.generate(data, 'standard_report.html')
```

**コマンドライン:**
```bash
python3 generate_report.py 21.0.6 21.0.7 21.0.8
```

### 2. Windows 11専用テンプレート (`windows11`)

**ファイル:** `templates/windows11_specialized_template.html`

**用途:** Windows 11環境への影響に特化した詳細レポート

**特徴:**
- カスタマイズ可能なサマリーカード（スタイル指定可能）
- キーファインディングセクション（主な発見事項を箇条書きで表示）
- 影響分析セクション（Windows 11環境への具体的な影響）
- 推奨アクションセクション（対応手順の提案）
- 優先度別にグループ化されたIssueテーブル（P2、P3、P4）
- Windows 11に最適化されたデザイン（Microsoft Fluent Design風）

**使用例:**
```python
from html_generator import HTMLGenerator, prepare_windows11_report_data
from jdk_issue_statistics import IssueStatistics

# Windows関連Issueをフィルタリング
windows_issues = stats.filter_issues(os='windows')
windows_stats = IssueStatistics(windows_issues)

# カスタム設定
custom_config = {
    'key_findings': {
        'title': '主な発見事項',
        'findings': [
            'Critical (P2) のIssueが3件含まれています',
            'hotspotコンポーネントで最も多くの変更があります',
            'バグ修正が15件含まれています'
        ]
    },
    'impact_section': {
        'title': 'Windows 11環境への影響',
        'content': '<p>詳細な影響分析...</p>'
    },
    'recommendations': {
        'title': '推奨アクション',
        'content': '<ol><li>高優先度Issueの確認</li><li>テスト環境での検証</li></ol>'
    }
}

generator = HTMLGenerator(template_name='windows11')
data = prepare_windows11_report_data(windows_stats, versions, custom_config)
generator.generate(data, 'windows11_report.html')
```

**コマンドライン:**
```bash
python3 generate_windows11_report.py 21.0.6 21.0.7 21.0.8
```

## テンプレートの選択基準

### 標準テンプレートを使用すべき場合

- すべてのIssueを対象とした包括的な分析が必要な場合
- 詳細な検索・フィルタリング機能が必要な場合
- 技術者向けの詳細レポートが必要な場合
- バージョン間の比較分析が主な目的の場合

### Windows 11専用テンプレートを使用すべき場合

- Windows 11環境への影響に焦点を当てたい場合
- 経営層や意思決定者向けに影響と推奨事項を明確に提示したい場合
- キーファインディングや推奨アクションを含む構造化されたレポートが必要な場合
- Windows関連Issueのみを抽出して詳細分析したい場合

## カスタムテンプレートの作成

新しいテンプレートを追加する場合は以下の手順に従います:

### 1. テンプレートファイルの作成

`templates/` ディレクトリに新しいHTMLテンプレートを作成します。

```html
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>{{ title }}</title>
    <!-- スタイルとスクリプト -->
</head>
<body>
    <!-- テンプレート内容 -->
</body>
</html>
```

### 2. HTMLGeneratorへの登録

`scripts/html_generator.py` の `TEMPLATES` 辞書に新しいテンプレートを追加します:

```python
class HTMLGenerator:
    TEMPLATES = {
        'standard': 'report_template.html',
        'windows11': 'windows11_specialized_template.html',
        'your_template': 'your_template.html'  # 追加
    }
```

### 3. データ準備関数の作成

新しいテンプレート用のデータ準備関数を作成します:

```python
def prepare_your_template_data(stats, versions, custom_config=None):
    """
    カスタムテンプレート用のデータ準備
    """
    config = custom_config or {}

    # データ準備ロジック
    return {
        'title': config.get('title', 'Default Title'),
        'data': ...,
        # その他のテンプレート変数
    }
```

### 4. ジェネレータースクリプトの作成（オプション）

便利なコマンドラインツールとして、専用のジェネレータースクリプトを作成します:

```python
#!/usr/bin/env python3
from html_generator import HTMLGenerator, prepare_your_template_data

def generate_custom_report(versions, output_file):
    generator = HTMLGenerator(template_name='your_template')
    data = prepare_your_template_data(stats, versions)
    generator.generate(data, output_file)
```

## テンプレート開発のベストプラクティス

1. **Jinja2テンプレート構文を使用**
   - 条件分岐: `{% if condition %} ... {% endif %}`
   - ループ: `{% for item in items %} ... {% endfor %}`
   - 変数展開: `{{ variable }}`

2. **JSONデータの安全な埋め込み**
   - `| safe` フィルターを使用してHTMLエスケープを回避
   - 例: `const data = {{ json_data | safe }};`

3. **Chart.jsの適切な読み込み**
   - `defer` 属性を使用してスクリプト読み込みを遅延
   - `DOMContentLoaded` イベントでJavaScriptを実行

4. **レスポンシブデザイン**
   - CSS Grid や Flexbox を活用
   - モバイルデバイスでも見やすいレイアウト

5. **アクセシビリティ**
   - 適切なセマンティックHTML
   - 色のコントラスト比の確保

## テスト

新しいテンプレートを作成したら、必ずテストを実行してください:

```bash
python3 test_multi_template.py
```

または、個別のテストスクリプトを作成:

```python
from html_generator import HTMLGenerator, prepare_your_template_data

generator = HTMLGenerator(template_name='your_template')
data = prepare_your_template_data(stats, versions)
generator.generate(data, 'test_output.html')
```

## トラブルシューティング

### テンプレートが見つからない

**エラー:** `ValueError: Unknown template: your_template`

**解決方法:** `HTMLGenerator.TEMPLATES` に登録されているか確認してください。

### Jinja2の構文エラー

**エラー:** `jinja2.exceptions.TemplateSyntaxError`

**解決方法:** テンプレートの構文を確認してください。特に:
- 閉じタグ漏れ（`{% endif %}`, `{% endfor %}`）
- 変数名のスペルミス
- Pythonの予約語（`items`, `keys`, `values`）をプロパティ名に使用していないか

### JSONデータがHTMLエスケープされる

**エラー:** JavaScriptで `&#34;` などの文字実体参照が表示される

**解決方法:** `| safe` フィルターを使用してください:
```html
<script>
const data = {{ json_data | safe }};
</script>
```

## パフォーマンス

マルチテンプレートシステムはテンプレート方式を採用しているため、高速にレポートを生成できます:

- **標準テンプレート:** 約0.003秒/レポート
- **Windows 11専用テンプレート:** 約0.003秒/レポート
- **スループット:** 約130,000 Issues/秒

テンプレートはキャッシュされるため、同じテンプレートを繰り返し使用する場合はさらに高速化されます。
