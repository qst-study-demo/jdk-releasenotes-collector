# クイックスタートガイド

## 5分でわかるJDK Issue Analyzer

### 1. 標準レポートの生成（最も簡単）

```bash
cd scripts
python3 generate_report.py 21.0.6 21.0.7 21.0.8
```

**生成されるもの:** インタラクティブなHTMLレポート（検索・フィルタ・ソート機能付き）

### 2. Windows 11専用レポートの生成

```bash
cd scripts
python3 generate_windows11_report.py 21.0.6 21.0.7 21.0.8
```

**生成されるもの:** Windows 11環境への影響に特化したレポート（キーファインディング、影響分析、推奨事項付き）

### 3. カスタムレポートの作成

```python
from html_components import (
    generate_summary_cards_section,
    generate_key_findings,
    wrap_in_html_template
)
from jdk_issue_statistics import load_multiple_files

# データ読み込み
stats = load_multiple_files(['../references/jdk_OpenJDK21_0_6_Released.txt'])

# サマリーカード作成
cards = generate_summary_cards_section([
    {'label': '総Issue数', 'value': len(stats.issues), 'style': 'total'},
    {'label': 'Critical', 'value': 5, 'style': 'critical'},
])

# キーファインディング作成
findings = generate_key_findings('主な発見事項', [
    'P2のIssueが5件あります',
    'hotspotで最も多くの変更があります'
])

# HTML生成
html = wrap_in_html_template(
    f'{cards}{findings}',
    title='カスタムレポート'
)

# 保存
with open('custom_report.html', 'w', encoding='utf-8') as f:
    f.write(html)
```

### 4. Issue検索

#### IDで検索
```bash
cd scripts
python3 search_issues.py --id JDK-8320192
```

#### キーワードで検索
```bash
python3 search_issues.py --search "Windows 11" --verbose
```

#### フィルタで検索
```bash
python3 search_issues.py --priority P2 --os windows
```

#### 統計情報付き検索
```bash
python3 search_issues.py --priority P2 --stats
```

## よくある使い方

### Windows 11への影響調査

```bash
# 1. Windows関連Issueを検索
python3 search_issues.py --os windows --verbose

# 2. Windows 11専用レポート生成
python3 generate_windows11_report.py 21.0.6

# 3. 高優先度のWindows関連Issueを詳細確認
python3 search_issues.py --os windows --priority P2 --verbose
```

### バージョン間の比較分析

```bash
# 複数バージョンを統合して分析
python3 search_issues.py --priority P2 --merge --stats --file \
  ../references/jdk_OpenJDK21_0_6_Released.txt \
  ../references/jdk_OpenJDK21_0_7_Released.txt \
  ../references/jdk_OpenJDK21_0_8_Released.txt
```

### セキュリティ関連の変更確認

```bash
# セキュリティキーワードで検索
python3 search_issues.py --search "security" --verbose

# security-libsコンポーネントの変更
python3 search_issues.py --component security-libs --stats
```

## レポート作成の選択フローチャート

```
レポートが必要？
├─ Yes → 標準的な形式で良い？
│         ├─ Yes → テンプレート方式
│         │         ├─ 全Issue対象 → generate_report.py
│         │         └─ Windows 11特化 → generate_windows11_report.py
│         │
│         └─ No → カスタムレイアウトが必要
│                   └─ 部品組み立て方式
│                       └─ html_components.py の部品を使用
│
└─ No → Issue検索のみ
          └─ search_issues.py
```

## ファイル構成

```
jdk-issue-analyzer/
├── scripts/
│   ├── generate_report.py              # 標準レポート生成
│   ├── generate_windows11_report.py    # Windows 11専用レポート生成
│   ├── html_generator.py               # テンプレートジェネレーター
│   ├── html_components.py              # HTML部品モジュール
│   ├── example_manual_report.py        # カスタムレポート作成例
│   ├── search_issues.py                # Issue検索
│   └── jdk_issue_statistics.py         # 統計分析
│
├── templates/
│   ├── report_template.html            # 標準テンプレート
│   └── windows11_specialized_template.html # Windows 11専用テンプレート
│
├── references/                          # データファイル
│   ├── jdk_OpenJDK21_0_6_Released.txt
│   ├── jdk_OpenJDK21_0_7_Released.txt
│   └── jdk_OpenJDK21_0_8_Released.txt
│
└── docs/
    ├── SKILL.md                         # スキル詳細ドキュメント
    ├── COMPONENTS.md                    # 部品化システムガイド
    ├── MULTI_TEMPLATE.md                # マルチテンプレートガイド
    └── QUICKSTART.md                    # このファイル
```

## トラブルシューティング

### データファイルが見つからない

**エラー:** `FileNotFoundError: jdk_OpenJDK21_0_6_Released.txt`

**解決方法:**
```bash
# カレントディレクトリを確認
pwd
# scriptsディレクトリに移動
cd scripts
```

### Jinja2がインストールされていない

**警告:** `Jinja2が利用できません`

**解決方法:**
```bash
pip install jinja2
```

（Jinja2がなくても動作しますが、インストールを推奨）

### HTMLレポートが表示されない

**原因:** ブラウザがローカルファイルのJavaScriptを実行できない

**解決方法:**
- Chromeの場合: `python3 -m http.server 8000` でローカルサーバーを起動し、`http://localhost:8000/report.html` にアクセス
- または、HTMLファイルをClaude Codeの `/mnt/user-data/outputs/` にコピーしてプレビュー

## 次のステップ

1. **詳細を学ぶ:**
   - [SKILL.md](SKILL.md) - 全機能の詳細説明
   - [COMPONENTS.md](COMPONENTS.md) - 部品化システムの詳細
   - [MULTI_TEMPLATE.md](MULTI_TEMPLATE.md) - テンプレートシステムの詳細

2. **サンプルを試す:**
   ```bash
   cd scripts
   python3 example_manual_report.py
   ```

3. **カスタマイズ:**
   - `example_manual_report.py` をコピーして編集
   - 必要な部品だけを選択して組み合わせ

## ヘルプ

各スクリプトのヘルプを表示:

```bash
python3 generate_report.py --help
python3 search_issues.py --help
```

オンラインドキュメント:
- [SKILL.md](SKILL.md) - 包括的なガイド
- [COMPONENTS.md](COMPONENTS.md) - 部品リファレンス
- [MULTI_TEMPLATE.md](MULTI_TEMPLATE.md) - テンプレートガイド
