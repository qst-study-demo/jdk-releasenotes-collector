#!/usr/bin/env python3
"""
HTMLコンポーネント生成モジュール

手作業でHTMLレポートを作成する際に使える部品を提供します。
各関数は独立して使用でき、必要な部品だけを組み合わせることができます。
"""

import json
from typing import List, Dict, Any, Optional


def generate_summary_card(label: str, value: int, description: str = '', style: str = 'total') -> str:
    """
    サマリーカードHTMLを生成

    Args:
        label: カードのラベル
        value: 表示する値
        description: 説明文（省略可）
        style: スタイル名（'total', 'critical', 'high', 'windows', 'security'）

    Returns:
        サマリーカードのHTML

    例:
        card = generate_summary_card('総Issue数', 77, 'このバージョンで修正された総数', 'total')
    """
    return f'''
    <div class="card {style}">
        <div class="card-label">{label}</div>
        <div class="card-value">{value}</div>
        {f'<small>{description}</small>' if description else ''}
    </div>
    '''


def generate_summary_cards_section(cards: List[Dict[str, Any]]) -> str:
    """
    サマリーカードセクション全体を生成

    Args:
        cards: カード情報のリスト
            - label: カードのラベル
            - value: 表示する値
            - description: 説明文（省略可）
            - style: スタイル名（省略可、デフォルト: 'total'）

    Returns:
        サマリーカードセクションのHTML

    例:
        cards = [
            {'label': '総Issue数', 'value': 77, 'description': '修正された総数', 'style': 'total'},
            {'label': 'Critical', 'value': 5, 'description': '最優先Issue', 'style': 'critical'},
        ]
        section = generate_summary_cards_section(cards)
    """
    cards_html = []
    for card in cards:
        cards_html.append(generate_summary_card(
            card['label'],
            card['value'],
            card.get('description', ''),
            card.get('style', 'total')
        ))

    return f'''
    <div class="summary-cards">
        {''.join(cards_html)}
    </div>
    '''


def generate_key_findings(title: str, findings: List[str]) -> str:
    """
    キーファインディングセクションを生成

    Args:
        title: セクションのタイトル
        findings: 発見事項のリスト

    Returns:
        キーファインディングセクションのHTML

    例:
        findings = [
            'Critical (P2) のIssueが5件含まれています',
            'hotspotコンポーネントで最も多くの変更があります',
        ]
        section = generate_key_findings('主な発見事項', findings)
    """
    findings_html = '\n'.join([f'<li>{finding}</li>' for finding in findings])

    return f'''
    <div class="key-findings">
        <h2 style="color: #0078d4; margin-bottom: 15px;">{title}</h2>
        <ul>
            {findings_html}
        </ul>
    </div>
    '''


def generate_impact_section(title: str, content: str) -> str:
    """
    影響分析セクションを生成

    Args:
        title: セクションのタイトル
        content: HTMLコンテンツ

    Returns:
        影響分析セクションのHTML

    例:
        content = '''
        <p>このバージョンでは、<strong>77件</strong>のIssueが確認されました。</p>
        <ul>
            <li>高優先度Issue: 10件</li>
            <li>主な影響コンポーネント: hotspot, security-libs</li>
        </ul>
        '''
        section = generate_impact_section('Windows 11環境への影響', content)
    """
    return f'''
    <div class="impact-section">
        <h3>{title}</h3>
        {content}
    </div>
    '''


def generate_recommendation_section(title: str, content: str) -> str:
    """
    推奨事項セクションを生成

    Args:
        title: セクションのタイトル
        content: HTMLコンテンツ（通常はリスト形式）

    Returns:
        推奨事項セクションのHTML

    例:
        content = '''
        <ol>
            <li>高優先度Issueの確認</li>
            <li>テスト環境での検証</li>
            <li>段階的な適用</li>
        </ol>
        '''
        section = generate_recommendation_section('推奨アクション', content)
    """
    return f'''
    <div class="recommendation">
        <h3>{title}</h3>
        {content}
    </div>
    '''


def generate_issue_table(issues: List[Dict[str, Any]],
                        columns: List[str] = None,
                        priority_label: Optional[str] = None,
                        color: Optional[str] = None) -> str:
    """
    Issueテーブルを生成

    Args:
        issues: Issueデータのリスト
            - id: Issue ID
            - title: タイトル
            - component: コンポーネント
            - priority: 優先度
            - type: タイプ
            - os: OS
        columns: 表示するカラムのリスト（省略時はすべて表示）
        priority_label: 優先度ラベル（テーブルタイトル）
        color: テーブルカラー（ヘッダー色）

    Returns:
        IssueテーブルのHTML

    例:
        issues = [
            {'id': 'JDK-8320192', 'title': 'Fix memory leak', 'component': 'hotspot',
             'priority': 'P2', 'type': 'Bug'},
        ]
        table = generate_issue_table(issues, columns=['id', 'title', 'priority'])
    """
    if columns is None:
        columns = ['id', 'title', 'component', 'priority', 'type']

    column_labels = {
        'id': 'Issue ID',
        'title': 'タイトル',
        'component': 'コンポーネント',
        'priority': '優先度',
        'type': 'タイプ',
        'os': 'OS',
        'version': 'バージョン'
    }

    # ヘッダー行
    header_html = '<tr>' + ''.join([f'<th>{column_labels.get(col, col)}</th>' for col in columns]) + '</tr>'

    # データ行
    rows_html = []
    for issue in issues:
        row = '<tr>'
        for col in columns:
            value = issue.get(col, '-')

            # 特殊な列の処理
            if col == 'id':
                row += f'<td><a href="https://bugs.openjdk.org/browse/{value}" target="_blank">{value}</a></td>'
            elif col == 'priority':
                row += f'<td><span class="priority-badge priority-{value}">{value}</span></td>'
            elif col == 'type':
                row += f'<td><span class="type-badge">{value}</span></td>'
            elif col == 'component':
                row += f'<td><span class="component-tag">{value}</span></td>'
            elif col == 'version':
                row += f'<td><span class="version-badge">{value}</span></td>'
            else:
                row += f'<td>{value}</td>'
        row += '</tr>'
        rows_html.append(row)

    # テーブル全体
    table_html = f'''
    {f'<h3 style="color: {color}; margin: 20px 0;">{priority_label}</h3>' if priority_label else ''}
    <table class="issue-table">
        <thead>
            {header_html}
        </thead>
        <tbody>
            {''.join(rows_html)}
        </tbody>
    </table>
    '''

    return table_html


def generate_chart_config(chart_id: str,
                         chart_type: str,
                         data: Dict[str, Any],
                         title: Optional[str] = None,
                         options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Chart.js用のチャート設定を生成

    Args:
        chart_id: チャートのHTML要素ID
        chart_type: チャートタイプ（'bar', 'pie', 'doughnut', 'line'など）
        data: チャートデータ（labels と datasets を含む辞書）
        title: チャートタイトル（省略可）
        options: 追加のチャートオプション（省略可）

    Returns:
        Chart.js設定の辞書

    例:
        config = generate_chart_config(
            'priorityChart',
            'bar',
            {
                'labels': ['P2', 'P3', 'P4'],
                'datasets': [{
                    'label': 'Issue数',
                    'data': [5, 20, 35],
                    'backgroundColor': '#0078d4'
                }]
            },
            title='優先度別分布'
        )
    """
    default_options = {
        'responsive': True,
        'maintainAspectRatio': True,
    }

    if title:
        default_options['plugins'] = {
            'title': {
                'display': True,
                'text': title
            }
        }

    if options:
        default_options.update(options)

    return {
        'id': chart_id,
        'config': {
            'type': chart_type,
            'data': data,
            'options': default_options
        }
    }


def generate_chart_section(chart_id: str, title: str) -> str:
    """
    チャートセクションのHTMLを生成

    Args:
        chart_id: チャートのHTML要素ID
        title: セクションのタイトル

    Returns:
        チャートセクションのHTML

    例:
        section = generate_chart_section('priorityChart', '優先度別分布')
    """
    return f'''
    <div class="section">
        <h2 class="section-title">{title}</h2>
        <div class="chart-container">
            <canvas id="{chart_id}"></canvas>
        </div>
    </div>
    '''


def generate_chart_script(chart_configs: List[Dict[str, Any]]) -> str:
    """
    Chart.jsのJavaScriptコードを生成

    Args:
        chart_configs: チャート設定のリスト（generate_chart_config()の戻り値）

    Returns:
        JavaScriptコード（scriptタグ内に記述する内容）

    例:
        configs = [
            generate_chart_config('priorityChart', 'bar', {...}),
            generate_chart_config('componentChart', 'doughnut', {...}),
        ]
        script = generate_chart_script(configs)
    """
    chart_configs_json = json.dumps(chart_configs, ensure_ascii=False)

    return f'''
    document.addEventListener('DOMContentLoaded', function() {{
        const chartConfigs = {chart_configs_json};

        chartConfigs.forEach(config => {{
            const ctx = document.getElementById(config.id).getContext('2d');
            new Chart(ctx, config.config);
        }});
    }});
    '''


def wrap_in_html_template(content: str,
                          title: str = 'JDK Issue Report',
                          css: Optional[str] = None,
                          js: Optional[str] = None) -> str:
    """
    コンテンツを完全なHTMLドキュメントとしてラップ

    Args:
        content: body内に挿入するHTMLコンテンツ
        title: ページタイトル
        css: 追加のCSSコード（省略可）
        js: 追加のJavaScriptコード（省略可）

    Returns:
        完全なHTMLドキュメント

    例:
        html = wrap_in_html_template(
            content='<h1>レポート</h1>',
            title='JDK 21.0.6 Analysis',
            css='.custom { color: red; }',
            js='console.log("loaded");'
        )
    """
    default_css = '''
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 20px;
        color: #333;
    }
    .container {
        max-width: 1400px;
        margin: 0 auto;
        background: white;
        border-radius: 20px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        overflow: hidden;
    }
    .header {
        background: linear-gradient(135deg, #0078d4 0%, #00bcf2 100%);
        color: white;
        padding: 40px;
        text-align: center;
    }
    .summary-cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        padding: 40px;
        background: #f8f9fa;
    }
    .card {
        background: white;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        text-align: center;
        transition: transform 0.3s ease;
    }
    .card:hover { transform: translateY(-5px); }
    .card-value {
        font-size: 3em;
        font-weight: bold;
        margin: 10px 0;
    }
    .card-label { color: #666; font-size: 1.1em; }
    .card.total .card-value { color: #0078d4; }
    .card.critical .card-value { color: #d13438; }
    .card.high .card-value { color: #ff8c00; }
    .content { padding: 40px; }
    .section { margin-bottom: 40px; }
    .section-title {
        font-size: 1.8em;
        margin-bottom: 20px;
        color: #0078d4;
        border-bottom: 3px solid #0078d4;
        padding-bottom: 10px;
    }
    .chart-container {
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        margin-bottom: 30px;
    }
    .key-findings {
        background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
        padding: 30px;
        border-radius: 15px;
        margin-bottom: 30px;
    }
    .key-findings ul { list-style: none; padding-left: 0; }
    .key-findings li {
        padding: 10px 0;
        padding-left: 30px;
        position: relative;
    }
    .key-findings li:before {
        content: "▶";
        position: absolute;
        left: 10px;
        color: #0078d4;
        font-size: 0.8em;
    }
    .impact-section {
        background: #fff3cd;
        border-left: 5px solid #ffc107;
        padding: 20px;
        margin: 20px 0;
        border-radius: 5px;
    }
    .recommendation {
        background: #d4edda;
        border-left: 5px solid #28a745;
        padding: 20px;
        margin: 20px 0;
        border-radius: 5px;
    }
    .issue-table {
        width: 100%;
        border-collapse: collapse;
        background: white;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        margin-bottom: 20px;
    }
    .issue-table th {
        background: #0078d4;
        color: white;
        padding: 15px;
        text-align: left;
        font-weight: 600;
    }
    .issue-table td {
        padding: 12px 15px;
        border-bottom: 1px solid #e0e0e0;
    }
    .issue-table tr:hover { background: #f5f5f5; }
    .priority-badge {
        display: inline-block;
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 0.9em;
        font-weight: 600;
    }
    .priority-P1 { background: #dc3545; color: white; }
    .priority-P2 { background: #ffe6e6; color: #d13438; }
    .priority-P3 { background: #fff4e6; color: #ff8c00; }
    .priority-P4 { background: #fffbe6; color: #f0ad4e; }
    .priority-P5 { background: #e9ecef; color: #6c757d; }
    .component-tag {
        display: inline-block;
        background: #e3f2fd;
        color: #0078d4;
        padding: 4px 10px;
        border-radius: 15px;
        font-size: 0.85em;
        margin: 2px;
    }
    .type-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 12px;
        font-size: 0.85em;
        background: #e9ecef;
        color: #495057;
    }
    .version-badge {
        display: inline-block;
        background: #6c757d;
        color: white;
        padding: 3px 8px;
        border-radius: 10px;
        font-size: 0.8em;
        margin-right: 5px;
    }
    '''

    return f'''<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js" defer></script>
    <style>
        {default_css}
        {css or ''}
    </style>
</head>
<body>
    <div class="container">
        {content}
    </div>
    <script>
        {js or ''}
    </script>
</body>
</html>
'''


# 使用例
if __name__ == '__main__':
    print("HTMLコンポーネントジェネレーター")
    print("\n利用可能な関数:")
    print("  - generate_summary_card(): サマリーカードを生成")
    print("  - generate_summary_cards_section(): サマリーカードセクションを生成")
    print("  - generate_key_findings(): キーファインディングセクションを生成")
    print("  - generate_impact_section(): 影響分析セクションを生成")
    print("  - generate_recommendation_section(): 推奨事項セクションを生成")
    print("  - generate_issue_table(): Issueテーブルを生成")
    print("  - generate_chart_config(): Chart.js設定を生成")
    print("  - generate_chart_section(): チャートセクションを生成")
    print("  - generate_chart_script(): Chart.jsスクリプトを生成")
    print("  - wrap_in_html_template(): 完全なHTMLドキュメントを生成")
    print("\n使用例:")
    print("  from html_components import generate_summary_card, wrap_in_html_template")
    print("  card = generate_summary_card('総Issue数', 77, '修正された総数')")
    print("  html = wrap_in_html_template(card, 'My Report')")
