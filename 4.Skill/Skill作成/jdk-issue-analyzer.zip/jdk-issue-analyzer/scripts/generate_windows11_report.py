#!/usr/bin/env python3
"""
Windows 11専用のHTMLレポート生成スクリプト

Windows 11環境への影響に特化した詳細レポートを生成します。
"""

import sys
from pathlib import Path
from html_generator import HTMLGenerator, prepare_windows11_report_data
from jdk_issue_statistics import load_multiple_files, IssueStatistics


def generate_windows11_impact_report(versions, output_file='windows11_impact_report.html'):
    """
    Windows 11影響分析レポートを生成

    Args:
        versions: JDKバージョンのリスト (例: ['21.0.6', '21.0.7'])
        output_file: 出力ファイル名
    """
    # データファイルのパスを構築
    base_dir = Path(__file__).parent.parent / 'references'
    filepaths = []

    for version in versions:
        version_clean = version.replace('.', '_')
        filepath = base_dir / f'jdk_OpenJDK{version_clean}_Released.txt'
        if not filepath.exists():
            print(f"警告: ファイルが見つかりません: {filepath}")
            continue
        filepaths.append(str(filepath))

    if not filepaths:
        print("エラー: 有効なデータファイルが見つかりませんでした")
        sys.exit(1)

    # データを読み込み
    print(f"データ読み込み中: {len(filepaths)}ファイル...")
    stats = load_multiple_files(filepaths)
    print(f"読み込み完了: {len(stats.issues)}件のIssue")

    # Windows関連Issueでフィルタリング
    windows_issues = stats.filter_issues(os='windows')
    windows_stats = IssueStatistics(windows_issues)
    print(f"Windows関連: {len(windows_stats.issues)}件")

    # キーファインディングを生成
    key_findings = {
        'title': '主な発見事項',
        'findings': []
    }

    p2_count = windows_stats.get_high_priority_count(['P2'])
    p3_count = windows_stats.get_high_priority_count(['P3'])

    if p2_count > 0:
        key_findings['findings'].append(f'Critical (P2) のIssueが{p2_count}件含まれています - 最優先で確認が必要です')

    if p3_count > 0:
        key_findings['findings'].append(f'High Priority (P3) のIssueが{p3_count}件含まれています')

    # コンポーネント分析
    component_stats = windows_stats.get_component_stats()
    if component_stats:
        top_component = max(component_stats.items(), key=lambda x: x[1])
        key_findings['findings'].append(f'{top_component[0]}コンポーネントで最も多くの変更（{top_component[1]}件）があります')

    # タイプ分析
    type_stats = windows_stats.get_type_stats()
    bug_count = type_stats.get('Bug', 0)
    if bug_count > 0:
        key_findings['findings'].append(f'バグ修正が{bug_count}件含まれています')

    # 影響セクション
    impact_section = {
        'title': 'Windows 11環境への影響',
        'content': f'''
        <p>このバージョンでは、Windows 11環境に影響を与える可能性のあるIssueが<strong>{len(windows_stats.issues)}件</strong>確認されました。</p>
        <ul>
            <li>高優先度Issue（P2-P3）: <strong>{p2_count + p3_count}件</strong></li>
            <li>主な影響コンポーネント: {', '.join(list(component_stats.keys())[:3])}</li>
            <li>バグ修正: {bug_count}件 / 機能追加・変更: {len(windows_stats.issues) - bug_count}件</li>
        </ul>
        <p>特に、P2のIssueについては本番環境への適用前に必ず動作確認を実施してください。</p>
        '''
    }

    # 推奨事項
    recommendations = {
        'title': '推奨アクション',
        'content': '''
        <ol>
            <li><strong>高優先度Issueの確認</strong>: P2およびP3のすべてのIssueについて、アプリケーションへの影響を評価してください</li>
            <li><strong>テスト環境での検証</strong>: Windows 11のテスト環境でアプリケーションの動作確認を実施してください</li>
            <li><strong>段階的な適用</strong>: 本番環境への適用は段階的に行い、各ステップで動作確認を行ってください</li>
            <li><strong>ロールバック計画</strong>: 問題が発生した場合に備えて、ロールバック手順を事前に準備してください</li>
        </ol>
        '''
    }

    # カスタム設定
    custom_config = {
        'title': f'Windows 11 Impact Analysis - JDK {", ".join(versions)}',
        'subtitle': f'Windows 11環境への影響分析レポート ({len(windows_stats.issues)}件のWindows関連Issue)',
        'header_icon': '🪟',
        'key_findings': key_findings,
        'impact_section': impact_section,
        'recommendations': recommendations,
        'summary_cards': [
            {'label': 'Windows関連Issue', 'value': len(windows_stats.issues), 'style': 'total', 'description': 'Windows環境で確認されたIssue総数'},
            {'label': 'Critical (P2)', 'value': p2_count, 'style': 'critical', 'description': '最優先で確認すべきIssue'},
            {'label': 'High Priority (P3)', 'value': p3_count, 'style': 'high', 'description': '重要度の高いIssue'},
        ]
    }

    # Windows 11専用テンプレートでレポート生成
    print(f"\nWindows 11専用レポート生成中...")
    generator = HTMLGenerator(template_name='windows11')
    data = prepare_windows11_report_data(windows_stats, versions, custom_config)
    generator.generate(data, output_file)

    print(f"✅ レポート生成完了: {output_file}")
    print(f"   - Windows関連Issue: {len(windows_stats.issues)}件")
    print(f"   - Critical (P2): {p2_count}件")
    print(f"   - High Priority (P3): {p3_count}件")


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("使用方法: python3 generate_windows11_report.py <version1> [version2] ...")
        print("\n例:")
        print("  python3 generate_windows11_report.py 21.0.6")
        print("  python3 generate_windows11_report.py 21.0.6 21.0.7 21.0.8")
        sys.exit(1)

    versions = sys.argv[1:]
    output_file = f'windows11_jdk_{"_".join(versions)}_report.html'

    generate_windows11_impact_report(versions, output_file)
