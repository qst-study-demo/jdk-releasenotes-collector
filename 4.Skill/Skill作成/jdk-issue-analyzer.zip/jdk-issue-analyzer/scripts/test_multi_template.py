#!/usr/bin/env python3
"""
マルチテンプレートシステムの統合テスト

標準テンプレートとWindows 11専用テンプレートの両方が正しく動作することを確認します。
"""

import os
from pathlib import Path
from html_generator import HTMLGenerator, prepare_report_data, prepare_windows11_report_data
from jdk_issue_statistics import load_multiple_files, IssueStatistics


def test_multi_template_system():
    """マルチテンプレートシステムの統合テスト"""
    print("=" * 60)
    print("マルチテンプレートシステム統合テスト")
    print("=" * 60)

    # テスト1: データ読み込み
    print("\n[テスト1] データ読み込み")
    versions = ['21.0.6']
    filepaths = ['../references/jdk_OpenJDK21_0_6_Released.txt']

    try:
        stats = load_multiple_files(filepaths)
        print(f"   ✅ {len(stats.issues)} 件のIssueを読み込み")
    except Exception as e:
        print(f"   ❌ エラー: {e}")
        return False

    # テスト2: 標準テンプレートでのレポート生成
    print("\n[テスト2] 標準テンプレートでのレポート生成")
    try:
        generator = HTMLGenerator(template_name='standard')
        data = prepare_report_data(stats, versions)
        generator.generate(data, 'test_standard_report.html')
        print(f"   ✅ 標準レポート生成成功")

        # ファイル存在確認
        if not os.path.exists('test_standard_report.html'):
            print(f"   ❌ ファイルが生成されていません")
            return False

        # HTML検証
        with open('test_standard_report.html', 'r', encoding='utf-8') as f:
            content = f.read()

        if '<!DOCTYPE html>' not in content:
            print(f"   ❌ HTML形式が不正です")
            return False

        print(f"   ✅ HTMLファイル検証成功")

    except Exception as e:
        print(f"   ❌ エラー: {e}")
        return False

    # テスト3: Windows 11専用テンプレートでのレポート生成
    print("\n[テスト3] Windows 11専用テンプレートでのレポート生成")
    try:
        # Windows関連Issueでフィルタリング
        windows_issues = stats.filter_issues(os='windows')
        windows_stats = IssueStatistics(windows_issues)
        print(f"   - Windows関連Issue: {len(windows_stats.issues)}件")

        # カスタム設定
        custom_config = {
            'key_findings': {
                'title': 'テスト用発見事項',
                'findings': [
                    'テストファインディング1',
                    'テストファインディング2',
                    'テストファインディング3'
                ]
            },
            'impact_section': {
                'title': 'テスト用影響分析',
                'content': '<p>これはテスト用の影響分析です。</p>'
            },
            'recommendations': {
                'title': 'テスト用推奨事項',
                'content': '<ul><li>推奨事項1</li><li>推奨事項2</li></ul>'
            }
        }

        generator = HTMLGenerator(template_name='windows11')
        data = prepare_windows11_report_data(windows_stats, versions, custom_config)
        generator.generate(data, 'test_windows11_report.html')
        print(f"   ✅ Windows 11専用レポート生成成功")

        # ファイル存在確認
        if not os.path.exists('test_windows11_report.html'):
            print(f"   ❌ ファイルが生成されていません")
            return False

        # HTML検証
        with open('test_windows11_report.html', 'r', encoding='utf-8') as f:
            content = f.read()

        checks = [
            ('DOCTYPE宣言', '<!DOCTYPE html>' in content),
            ('タイトル', 'Windows 11 Impact Analysis' in content),
            ('キーファインディング', 'テスト用発見事項' in content),
            ('ファインディング項目', 'テストファインディング1' in content),
            ('影響セクション', 'テスト用影響分析' in content),
            ('推奨事項', 'テスト用推奨事項' in content),
            ('Chart.js', 'chart.js' in content),
        ]

        all_passed = True
        for name, result in checks:
            status = "✅" if result else "❌"
            print(f"   {status} {name}")
            if not result:
                all_passed = False

        if not all_passed:
            return False

    except Exception as e:
        print(f"   ❌ エラー: {e}")
        import traceback
        traceback.print_exc()
        return False

    # テスト4: テンプレート名の検証
    print("\n[テスト4] テンプレート名の検証")
    try:
        # 存在しないテンプレート名でエラーになることを確認
        try:
            generator = HTMLGenerator(template_name='invalid_template')
            print(f"   ❌ 無効なテンプレート名がエラーになりませんでした")
            return False
        except ValueError as e:
            print(f"   ✅ 無効なテンプレート名が正しく検出されました")

    except Exception as e:
        print(f"   ❌ 予期しないエラー: {e}")
        return False

    # テスト5: 利用可能なテンプレートの確認
    print("\n[テスト5] 利用可能なテンプレートの確認")
    try:
        available_templates = list(HTMLGenerator.TEMPLATES.keys())
        print(f"   利用可能なテンプレート: {available_templates}")

        expected_templates = ['standard', 'windows11']
        for template in expected_templates:
            if template in available_templates:
                print(f"   ✅ {template} テンプレートが利用可能")
            else:
                print(f"   ❌ {template} テンプレートが見つかりません")
                return False

    except Exception as e:
        print(f"   ❌ エラー: {e}")
        return False

    # クリーンアップ
    print("\n[クリーンアップ]")
    try:
        os.remove('test_standard_report.html')
        os.remove('test_windows11_report.html')
        print("   ✅ テストファイルを削除")
    except:
        pass

    print("\n" + "=" * 60)
    print("✅ すべてのテストが成功しました！")
    print("=" * 60)
    print("\n📊 テスト結果サマリー:")
    print("  - 標準テンプレート: 動作確認")
    print("  - Windows 11専用テンプレート: 動作確認")
    print("  - テンプレート切り替え: 正常")
    print("  - エラーハンドリング: 正常")
    return True


if __name__ == '__main__':
    success = test_multi_template_system()
    exit(0 if success else 1)
