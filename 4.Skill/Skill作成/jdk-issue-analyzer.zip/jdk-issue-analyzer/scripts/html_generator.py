#!/usr/bin/env python3
"""
HTMLテンプレートジェネレーター

テンプレートを使用してHTMLレポートを高速生成します。
"""

import json
import os
from typing import Dict, List, Any
from pathlib import Path

try:
    from jinja2 import Environment, FileSystemLoader, select_autoescape
    JINJA2_AVAILABLE = True
except ImportError:
    JINJA2_AVAILABLE = False


class HTMLGenerator:
    """HTMLレポートを効率的に生成するジェネレータークラス"""

    # 利用可能なテンプレート
    TEMPLATES = {
        'standard': 'report_template.html',
        'windows11': 'windows11_specialized_template.html'
    }

    def __init__(self, template_dir: str = None, template_name: str = 'standard'):
        """
        初期化

        Args:
            template_dir: テンプレートディレクトリのパス（省略時は自動検出）
            template_name: 使用するテンプレート名 ('standard' or 'windows11')
        """
        if template_dir is None:
            # スクリプトのディレクトリから相対パスでテンプレートディレクトリを取得
            script_dir = Path(__file__).parent
            template_dir = script_dir.parent / 'templates'

        self.template_dir = Path(template_dir)

        # テンプレート名の検証
        if template_name not in self.TEMPLATES:
            raise ValueError(f"Unknown template: {template_name}. Available: {list(self.TEMPLATES.keys())}")

        self.template_name = template_name
        self.template_file = self.TEMPLATES[template_name]

        if JINJA2_AVAILABLE:
            # Jinja2環境の設定
            # autoescapeは無効化（JSONデータをそのまま埋め込むため）
            self.env = Environment(
                loader=FileSystemLoader(str(self.template_dir)),
                autoescape=False
            )
            self.use_jinja2 = True
        else:
            # Jinja2が利用できない場合は単純な置換を使用
            self.use_jinja2 = False
            self._load_template()

    def _load_template(self):
        """テンプレートを読み込む（Jinja2未使用時）"""
        template_path = self.template_dir / self.template_file
        with open(template_path, 'r', encoding='utf-8') as f:
            self.template = f.read()

    def generate(self, data: Dict[str, Any], output_file: str) -> None:
        """
        HTMLレポートを生成

        Args:
            data: テンプレートに渡すデータ
            output_file: 出力ファイルパス
        """
        if self.use_jinja2:
            self._generate_with_jinja2(data, output_file)
        else:
            self._generate_with_replace(data, output_file)

    def _generate_with_jinja2(self, data: Dict[str, Any], output_file: str) -> None:
        """Jinja2を使用してHTMLを生成"""
        template = self.env.get_template(self.template_file)
        html_content = template.render(**data)

        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)

    def _generate_with_replace(self, data: Dict[str, Any], output_file: str) -> None:
        """単純な置換を使用してHTMLを生成（Jinja2未使用時）"""
        html_content = self.template

        # プレースホルダーを置換
        for key, value in data.items():
            placeholder = f'{{{{ {key} }}}}'

            # 値をJSON形式に変換（必要な場合）
            if isinstance(value, (dict, list)):
                value = json.dumps(value, ensure_ascii=False)

            html_content = html_content.replace(placeholder, str(value))

        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)


def generate_type_options(type_stats: Dict[str, int]) -> str:
    """タイプフィルタのオプションを生成"""
    options = []
    for type_name in sorted(type_stats.keys()):
        options.append(f'<option value="{type_name}">{type_name}</option>')
    return '\n'.join(options)


def generate_component_options(component_stats: Dict[str, int]) -> str:
    """コンポーネントフィルタのオプションを生成"""
    options = []
    # 上位15コンポーネントのみ表示
    top_components = sorted(component_stats.items(), key=lambda x: x[1], reverse=True)[:15]
    for component, _ in top_components:
        options.append(f'<option value="{component}">{component}</option>')
    return '\n'.join(options)


def prepare_report_data(stats, versions: List[str], custom_config: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    標準レポート生成に必要なデータを準備

    Args:
        stats: IssueStatistics オブジェクト
        versions: 分析対象のJDKバージョンリスト
        custom_config: カスタム設定

    Returns:
        テンプレートに渡すデータの辞書
    """
    config = custom_config or {}

    # 統計データの準備
    priority_stats = stats.get_priority_stats()
    component_stats = stats.get_component_stats()
    type_stats = stats.get_type_stats()
    os_stats = stats.get_os_stats()

    high_priority_count = stats.get_high_priority_count(['P1', 'P2'])
    windows_count = stats.get_windows_related_count()
    security_count = stats.get_security_related_count()

    # Issue一覧をJSON形式で準備
    issues_data = []
    for issue in stats.issues:
        issues_data.append({
            'id': issue.issue_id,
            'title': issue.title,
            'priority': issue.priority,
            'type': issue.type,
            'component': issue.component,
            'os': issue.os or '',
            'description': issue.description[:200] + '...' if len(issue.description) > 200 else issue.description
        })

    # レポートタイトルとサマリー
    title = config.get('title', f'JDK Issue Analysis Report - {", ".join(versions)}')
    summary = config.get('summary', 'JDKバージョン間のIssue分析レポート')

    # テンプレートデータの準備
    return {
        'title': title,
        'summary': summary,
        'versions_text': ', '.join(versions),
        'total_issues': len(stats.issues),
        'high_priority_count': high_priority_count,
        'windows_count': windows_count,
        'security_count': security_count,
        'issues_data': json.dumps(issues_data, ensure_ascii=False),
        'priority_stats': json.dumps(priority_stats),
        'component_stats': json.dumps(component_stats),
        'type_stats': json.dumps(type_stats),
        'os_stats': json.dumps(os_stats),
        'type_options': generate_type_options(type_stats),
        'component_options': generate_component_options(component_stats)
    }


def prepare_windows11_report_data(stats, versions: List[str], custom_config: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Windows 11専用レポート生成に必要なデータを準備

    Args:
        stats: IssueStatistics オブジェクト
        versions: 分析対象のJDKバージョンリスト
        custom_config: カスタム設定（key_findings, impact_section, recommendations等）

    Returns:
        Windows 11テンプレートに渡すデータの辞書
    """
    config = custom_config or {}

    # 統計データの準備
    priority_stats = stats.get_priority_stats()
    component_stats = stats.get_component_stats()
    type_stats = stats.get_type_stats()

    high_priority_count = stats.get_high_priority_count(['P1', 'P2'])
    windows_count = stats.get_windows_related_count()
    critical_count = stats.get_high_priority_count(['P2'])

    # サマリーカードの準備
    summary_cards = config.get('summary_cards', [
        {'label': '総Issue数', 'value': len(stats.issues), 'style': 'total', 'description': 'このバージョンで修正・追加された総数'},
        {'label': 'Critical (P2)', 'value': critical_count, 'style': 'critical', 'description': '最優先で確認すべきIssue'},
        {'label': 'High Priority (P3)', 'value': stats.get_high_priority_count(['P3']), 'style': 'high', 'description': '重要度の高いIssue'},
    ])

    # キーファインディングの準備
    key_findings = config.get('key_findings', None)

    # チャート設定の準備
    charts = config.get('charts', [
        {'id': 'priorityChart', 'title': '優先度別分布'},
        {'id': 'componentChart', 'title': 'コンポーネント別分布 (Top 10)'},
    ])

    # Chart.js用の設定
    chart_configs = []

    # 優先度チャート
    chart_configs.append({
        'id': 'priorityChart',
        'config': {
            'type': 'bar',
            'data': {
                'labels': list(priority_stats.keys()),
                'datasets': [{
                    'label': 'Issue数',
                    'data': list(priority_stats.values()),
                    'backgroundColor': '#0078d4',
                    'borderRadius': 8
                }]
            },
            'options': {
                'responsive': True,
                'maintainAspectRatio': True,
                'plugins': {'legend': {'display': False}}
            }
        }
    })

    # コンポーネントチャート (Top 10)
    top_components = dict(sorted(component_stats.items(), key=lambda x: x[1], reverse=True)[:10])
    chart_configs.append({
        'id': 'componentChart',
        'config': {
            'type': 'doughnut',
            'data': {
                'labels': list(top_components.keys()),
                'datasets': [{
                    'data': list(top_components.values()),
                    'backgroundColor': [
                        '#0078d4', '#00bcf2', '#8e8cd8', '#7c4dff',
                        '#ea4335', '#fbbc04', '#34a853', '#673ab7',
                        '#ff6f00', '#00bfa5'
                    ]
                }]
            },
            'options': {
                'responsive': True,
                'maintainAspectRatio': True,
                'plugins': {'legend': {'position': 'right'}}
            }
        }
    })

    # Issueテーブルの準備（優先度別）
    issue_tables = []
    for priority in ['P2', 'P3', 'P4']:
        priority_issues = [issue for issue in stats.issues if issue.priority == priority]
        if priority_issues:
            issue_tables.append({
                'priority_label': f'{priority} Issues ({len(priority_issues)}件)',
                'color': {'P2': '#d13438', 'P3': '#ff8c00', 'P4': '#f0ad4e'}[priority],
                'issues': [{
                    'id': issue.issue_id,
                    'title': issue.title,
                    'component': issue.component,
                    'version': versions[0] if versions else 'N/A'
                } for issue in priority_issues[:20]]  # 各優先度につき最大20件
            })

    # レポートタイトルとサブタイトル
    title = config.get('title', f'Windows 11 Impact Analysis - JDK {", ".join(versions)}')
    subtitle = config.get('subtitle', 'Windows 11環境への影響分析レポート')

    # テンプレートデータの準備
    return {
        'title': title,
        'subtitle': subtitle,
        'header_icon': config.get('header_icon', '🪟'),
        'summary_cards': summary_cards,
        'key_findings': key_findings,
        'charts': charts,
        'chart_configs': json.dumps(chart_configs, ensure_ascii=False),
        'impact_section': config.get('impact_section', None),
        'recommendations': config.get('recommendations', None),
        'issue_tables': issue_tables,
        'issue_tables_title': config.get('issue_tables_title', '詳細Issue一覧'),
    }


# 使用例
if __name__ == '__main__':
    print("HTMLGenerator モジュール")
    print(f"Jinja2サポート: {'有効' if JINJA2_AVAILABLE else '無効（pip install jinja2を推奨）'}")
    print(f"\n利用可能なテンプレート: {list(HTMLGenerator.TEMPLATES.keys())}")
    print("\n使用方法:")
    print("\n1. 標準レポート:")
    print("  from html_generator import HTMLGenerator, prepare_report_data")
    print("  generator = HTMLGenerator(template_name='standard')")
    print("  data = prepare_report_data(stats, versions)")
    print("  generator.generate(data, 'output.html')")
    print("\n2. Windows 11専用レポート:")
    print("  from html_generator import HTMLGenerator, prepare_windows11_report_data")
    print("  generator = HTMLGenerator(template_name='windows11')")
    print("  custom_config = {")
    print("      'key_findings': {")
    print("          'title': '主な発見事項',")
    print("          'findings': ['P2のIssueが3件含まれます', ...]")
    print("      },")
    print("      'impact_section': {")
    print("          'title': 'Windows 11への影響',")
    print("          'content': '<p>...</p>'")
    print("      }")
    print("  }")
    print("  data = prepare_windows11_report_data(stats, versions, custom_config)")
    print("  generator.generate(data, 'windows11_report.html')")
