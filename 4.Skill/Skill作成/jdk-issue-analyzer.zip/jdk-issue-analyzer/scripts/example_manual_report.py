#!/usr/bin/env python3
"""
手作業でHTMLレポートを作成する例

html_components モジュールの部品を使って、カスタムレポートを手作業で組み立てる方法を示します。
"""

from html_components import (
    generate_summary_cards_section,
    generate_key_findings,
    generate_impact_section,
    generate_recommendation_section,
    generate_issue_table,
    generate_chart_config,
    generate_chart_section,
    generate_chart_script,
    wrap_in_html_template
)
from jdk_issue_statistics import load_multiple_files


def create_custom_report():
    """カスタムレポートを手作業で組み立てる例"""

    # データの読み込み
    print("データ読み込み中...")
    stats = load_multiple_files(['../references/jdk_OpenJDK21_0_6_Released.txt'])
    print(f"読み込み完了: {len(stats.issues)}件のIssue")

    # ===== 1. ヘッダー部分 =====
    header = '''
    <div class="header">
        <h1>🔍 JDK 21.0.6 カスタム分析レポート</h1>
        <p>手作業で組み立てたカスタムレポートの例</p>
    </div>
    '''

    # ===== 2. サマリーカード =====
    p2_count = stats.get_high_priority_count(['P2'])
    p3_count = stats.get_high_priority_count(['P3'])
    windows_count = stats.get_windows_related_count()

    summary_cards = generate_summary_cards_section([
        {
            'label': '総Issue数',
            'value': len(stats.issues),
            'description': 'JDK 21.0.6で修正・追加',
            'style': 'total'
        },
        {
            'label': 'Critical (P2)',
            'value': p2_count,
            'description': '最優先で確認すべき',
            'style': 'critical'
        },
        {
            'label': 'High Priority (P3)',
            'value': p3_count,
            'description': '重要度が高い',
            'style': 'high'
        },
        {
            'label': 'Windows関連',
            'value': windows_count,
            'description': 'Windows環境に影響',
            'style': 'windows'
        }
    ])

    # ===== 3. キーファインディング =====
    findings = []
    if p2_count > 0:
        findings.append(f'Critical (P2) のIssueが{p2_count}件含まれています - 最優先で確認が必要です')
    if p3_count > 0:
        findings.append(f'High Priority (P3) のIssueが{p3_count}件含まれています')

    # コンポーネント分析
    component_stats = stats.get_component_stats()
    if component_stats:
        top_component = max(component_stats.items(), key=lambda x: x[1])
        findings.append(f'{top_component[0]}コンポーネントで最も多くの変更（{top_component[1]}件）があります')

    # タイプ分析
    type_stats = stats.get_type_stats()
    bug_count = type_stats.get('Bug', 0)
    if bug_count > 0:
        findings.append(f'バグ修正が{bug_count}件含まれています')

    key_findings = generate_key_findings('主な発見事項', findings)

    # ===== 4. チャート =====
    # 優先度チャート設定
    priority_stats = stats.get_priority_stats()
    priority_chart_config = generate_chart_config(
        'priorityChart',
        'bar',
        {
            'labels': list(priority_stats.keys()),
            'datasets': [{
                'label': 'Issue数',
                'data': list(priority_stats.values()),
                'backgroundColor': '#0078d4',
                'borderRadius': 8
            }]
        },
        title='優先度別分布'
    )

    # コンポーネントチャート設定（Top 10）
    top_components = dict(sorted(component_stats.items(), key=lambda x: x[1], reverse=True)[:10])
    component_chart_config = generate_chart_config(
        'componentChart',
        'doughnut',
        {
            'labels': list(top_components.keys()),
            'datasets': [{
                'data': list(top_components.values()),
                'backgroundColor': [
                    '#0078d4', '#00bcf2', '#8e8cd8', '#7c4dff',
                    '#ea4335', '#fbbc04', '#34a853', '#673ab7',
                    '#ff6f00', '#00bfa5'
                ]
            }]
        }
    )

    # チャートセクションHTML
    priority_chart_section = generate_chart_section('priorityChart', '優先度別分布')
    component_chart_section = generate_chart_section('componentChart', 'コンポーネント別分布 (Top 10)')

    # チャートスクリプト
    chart_script = generate_chart_script([priority_chart_config, component_chart_config])

    # ===== 5. 影響分析 =====
    impact_content = f'''
    <p>このバージョンでは、合計<strong>{len(stats.issues)}件</strong>のIssueが修正・追加されました。</p>
    <ul>
        <li>高優先度Issue（P2-P3）: <strong>{p2_count + p3_count}件</strong></li>
        <li>Windows関連Issue: <strong>{windows_count}件</strong></li>
        <li>主な影響コンポーネント: {', '.join(list(component_stats.keys())[:5])}</li>
        <li>バグ修正: {bug_count}件 / その他: {len(stats.issues) - bug_count}件</li>
    </ul>
    <p>特に、P2のIssueについては本番環境への適用前に必ず動作確認を実施してください。</p>
    '''
    impact_section = generate_impact_section('このバージョンの影響', impact_content)

    # ===== 6. 推奨事項 =====
    recommendation_content = '''
    <ol>
        <li><strong>高優先度Issueの確認</strong>: P2およびP3のすべてのIssueについて、アプリケーションへの影響を評価してください</li>
        <li><strong>コンポーネント別の確認</strong>: 使用しているJDKコンポーネントに関連するIssueを重点的に確認してください</li>
        <li><strong>テスト環境での検証</strong>: 本番環境への適用前に、必ずテスト環境で動作確認を実施してください</li>
        <li><strong>ロールバック計画</strong>: 問題が発生した場合に備えて、ロールバック手順を事前に準備してください</li>
    </ol>
    '''
    recommendation_section = generate_recommendation_section('推奨アクション', recommendation_content)

    # ===== 7. Issueテーブル（優先度別） =====
    tables_html = '<div class="content"><h2 class="section-title">Issue一覧（優先度別）</h2>'

    for priority in ['P2', 'P3', 'P4']:
        priority_issues = [issue for issue in stats.issues if issue.priority == priority]
        if priority_issues:
            # Issue情報を辞書に変換
            issue_dicts = [{
                'id': issue.issue_id,
                'title': issue.title,
                'component': issue.component,
                'type': issue.type,
                'priority': issue.priority
            } for issue in priority_issues[:20]]  # 最大20件

            priority_colors = {
                'P2': '#d13438',
                'P3': '#ff8c00',
                'P4': '#f0ad4e'
            }

            table = generate_issue_table(
                issue_dicts,
                columns=['id', 'title', 'component', 'type'],
                priority_label=f'{priority} Issues ({len(priority_issues)}件)',
                color=priority_colors[priority]
            )
            tables_html += table

    tables_html += '</div>'

    # ===== 8. すべてを組み立てる =====
    content = f'''
        {header}
        {summary_cards}
        <div class="content">
            {key_findings}
            {priority_chart_section}
            {component_chart_section}
            {impact_section}
            {recommendation_section}
        </div>
        {tables_html}
    '''

    # 完全なHTMLドキュメントを生成
    html = wrap_in_html_template(
        content,
        title='JDK 21.0.6 カスタム分析レポート',
        js=chart_script
    )

    # ファイルに保存
    output_file = 'custom_manual_report.html'
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(html)

    print(f"\n✅ カスタムレポート生成完了: {output_file}")
    print(f"   - 総Issue数: {len(stats.issues)}件")
    print(f"   - Critical (P2): {p2_count}件")
    print(f"   - High Priority (P3): {p3_count}件")
    print(f"   - Windows関連: {windows_count}件")
    print("\n📝 このレポートは html_components の部品を使って手作業で組み立てました")


if __name__ == '__main__':
    create_custom_report()
